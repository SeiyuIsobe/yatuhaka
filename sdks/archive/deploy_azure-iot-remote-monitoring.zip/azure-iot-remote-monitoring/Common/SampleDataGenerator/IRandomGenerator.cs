﻿namespace Microsoft.Azure.Devices.Applications.RemoteMonitoring.Common.SampleDataGenerator
{
    public interface IRandomGenerator
    {
        double GetRandomDouble();
    }
}
