﻿#if WINDOWS_UWP
namespace Microsoft.Azure.Devices.Applications.RemoteMonitoring.Common.Helpers
{
    internal interface ICustomTypeDescriptor
    {
    }
}
#endif