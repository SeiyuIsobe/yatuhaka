﻿namespace Microsoft.Azure.Devices.Applications.RemoteMonitoring.DeviceAdmin.Web.DataTables
{
    public class Search
    {
        public string Value { get; set; }
    }
}
