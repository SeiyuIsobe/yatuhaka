﻿namespace Microsoft.Azure.Devices.Applications.RemoteMonitoring.DeviceAdmin.Web.Models
{
    public class SecurityKeysModel
    {
        public string PrimaryKey { get; set; }
        public string SecondaryKey { get; set; }
    }
}