﻿namespace Microsoft.Azure.Devices.Applications.RemoteMonitoring.DeviceAdmin.Infrastructure.Models
{
    public enum QuerySortOrder
    {
        Ascending,
        Descending
    }
}
