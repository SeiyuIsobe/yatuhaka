﻿namespace Microsoft.Azure.Devices.Applications.RemoteMonitoring.DeviceAdmin.Web.Models
{
    public class UpdateKeyModel
    {
        public string DeviceId { get; set; }
        public string KeyType { get; set; }
    }
}